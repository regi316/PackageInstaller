﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PackageInstallerV2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGet_Click(object sender, EventArgs e)
        {
            string input = string.Empty;
            Ordering objOrder = new Ordering();

            input = txtInput.Text.ToString().Trim();
            lblresult.Text = objOrder.DetermineOrder(input);

        }
    }
}