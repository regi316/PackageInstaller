﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(PluralSight_PackageInstaller.Startup))]
namespace PluralSight_PackageInstaller
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
