﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UnitTest
/// </summary>
public class UnitTest
{
    public UnitTest()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}