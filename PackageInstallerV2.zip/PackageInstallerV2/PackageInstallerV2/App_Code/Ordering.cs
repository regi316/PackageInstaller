﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Ordering
/// </summary>
public class Ordering
{

    /// <summary>
    /// Get the list of software based on the order of installation
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public string DetermineOrder (string input)
    {
        string result = string.Empty;
        char[] charsToTrim = { '[', ']', ' ', ',', '"'};
        List<string> resultant = new List<string>();
        //bool firstInstall = false;
        try
        {
            //Remove the escape sequences and other inappropriate special characters in order to process more structured data
            input = input.Trim(charsToTrim);
            input = input.Replace('"', ' ');
            input = input.Replace('\r', ' ');
            input = input.Replace('\n', ' ');

            //Convert the structured format into array
            string[] dependencies =input.Split(',');

            foreach (string depends in dependencies)
            {
                //Form an array for simple iteration
                depends.Trim(charsToTrim);
                string[] software = depends.Split(':');

                //find the first software to install
                if (software[1].ToString().Trim() == "")
                {
                    resultant.Add(software[0].ToString().Trim());
                }
            }

            //Proceed to find the dependencies only when there is a primary software to install
            if (resultant.Count != 0)
            {
                //Get the dependencies and order as it finds
                for (int i = 0; i < dependencies.Length; i++)
                {
                    string addSoft = GetDependency(dependencies, resultant);
                    if(addSoft != "")
                        resultant.Add(addSoft);
                    string[] softwareDep = dependencies[i].Split(':');
                }

                //Number of software should be equal to the number of dependencies
                if (dependencies.Length == resultant.Count)
                {
                    result = string.Join(", ", resultant.ToArray());
                }
                else
                {
                    result = "Invalid Input. The input contains a cycle";
                }
            }
            //Otherwise the format is wrong
            else
            {
                result = "Invalid Input. The input contains a cycle";
            }
            
        }
        catch(Exception ex)
        {
            result = "Invalid input format. Please enter valid format";
        }
        
        return result;
        
    }

    /// <summary>
    /// Get the dependency
    /// </summary>
    /// <param name="dependencies"></param>
    /// <param name="software"></param>
    /// <returns></returns>
    private string GetDependency(string[] dependencies, List<string> software)
    {
        string dependentSoftware = string.Empty;

        foreach (string depends in dependencies)
        {
            string[] soft = depends.Split(':');
            if (software.Contains(soft[1].ToString().Trim()))
            {
                if (!software.Contains(soft[0].ToString().Trim()))
                {
                    dependentSoftware = soft[0].ToString().Trim();
                    break;
                }
            }
        }
        return dependentSoftware;

    }
}