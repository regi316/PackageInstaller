﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PackageInstallerV2;

namespace PackageInstallerTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void  Valid_Test1()
        {
            Ordering objOrder = new Ordering();

            string input = "[ \"KittenService: CamelCaser\", \"CamelCaser: \" ";

            string expected = "CamelCaser, KittenService";
            string actual = objOrder.DetermineOrder(input);
            Assert.AreEqual(expected, actual);

        }

        [TestMethod]
        public void Valid_Test2()
        {
            Ordering objOrder = new Ordering();

            string input = "[\"KittenService: \", \"Leetmeme: Cyberportal\", \"Cyberportal: Ice\", \"CamelCaser: KittenService\", \"Fraudstream: Leetmeme\", \"Ice: \"]";

            string expected = "KittenService, Ice, Cyberportal, Leetmeme, CamelCaser, Fraudstream";
            string actual = objOrder.DetermineOrder(input);
            Assert.AreEqual(expected, actual);

        }

        [TestMethod]
        public void inValid_Test1()
        {
            Ordering objOrder = new Ordering();

            string input = "[\"KittenService: \", \"Leetmeme: Cyberportal\", \"Cyberportal: Ice\", \"CamelCaser: KittenService\", \"Fraudstream: \", \"Ice: Leetmeme\"]";

            string expected = "Invalid Input. The input contains a cycle";
            string actual = objOrder.DetermineOrder(input);
            Assert.AreEqual(expected, actual);

        }
    }
}
